import Hero from "./_sections/Hero"
import Team from "./_sections/Team"
import Impact from "./_sections/Impact"



export default function About() {
  return (
    <>
      <Hero />
      <Team />
      <Impact/>

     
    </>
  )
}

