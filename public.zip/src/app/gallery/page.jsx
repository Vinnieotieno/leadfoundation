import Grid from "./_sections/Grid"
import Join from "./_sections/Join"
import Event from "./_sections/Event"



export default function About() {
  return (
    <>
      <Grid />
      <Event/>
      <Join />
     
    </>
  )
}

