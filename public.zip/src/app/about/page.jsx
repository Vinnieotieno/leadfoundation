import Hero from "./_sections/Hero"
import Join from "./_sections/Join"



export default function About() {
  return (
    <>
      <Hero />
      <Join />
     
    </>
  )
}

