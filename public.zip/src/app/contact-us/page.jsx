import Form from "./_sections/Form"
import Impact from "./_sections/Impact"



export default function About() {
  return (
    <>
      <Form />
      <Impact/>
     
    </>
  )
}

